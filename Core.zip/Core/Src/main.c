#include "stdio.h"
#include "string.h"
#include "main.h"

UART_HandleTypeDef huart3;
DMA_HandleTypeDef handle_GPDMA1_Channel7;

uint8_t aRxBuffer[1000];
uint8_t aHistoryBuffer[1000];
uint8_t myBuffer[100] =  {0};//TO GUARANTEE THAT IS FULFFILLED BY 0.

uint8_t myBuffer2[] =  "\n\r--------------- ------------------\n\nType Your Command: \r";
uint8_t aTxStartMessage[] = "\n\r---- Welcome to Command Line Interface Demo Application (CLI) ----\n\r";
uint8_t aTxEndMessage[] = "\n\n\r----END OF COMMAND LINE INTERFACE (CLI)----\n\r";
uint8_t aHelpMessage[] = "\n\n\rThis is a demo application of CLI via STM32.\n\n\rCommands available on this demo app:\n\n\rBOARD-INFO: Gives the board name and ID.\n\rUART-CONFIGINFO: Gives the UART configuartion.\n\rDMA-CONFIGINFO: Gives the DMA configuartion.\n\rLEDS-STATUS: Gives the status of leds.\n\rLEDS-ON: Turns the leds on.\n\rLEDS-OFF: Turns the leds off.\n\rHELP: Gives the list of all command in CLI.\n\rHISTORY: Gives the history of all commands inputted.\n\rRESET: Resets and restarts the CPU via Interrupt.\n\rEXIT: Finishes the demo application.\n\r";
uint8_t aResestMessage[] = "\n\n\rSystem will now be resetted and restarted!\n\r";
uint8_t aUartConfigInfoMessage[] = "\n\n\rINSTANCE = USART3\n\rBAUDRATE = 115200\n\rWORDLENGTH = UART_WORDLENGTH_8B\n\rSTOP BITS = UART_STOPBITS_1\n\rPARITY = UART_PARITY_NONE\n\rMODE = UART_MODE_TX_RX\n\rHARDWARE FLOW CONTROL = UART_HWCONTROL_NONE\n\rOVERSAMPLING = UART_OVERSAMPLING_16\n\rONE BIT SAMPLING = UART_ONE_BIT_SAMPLE_DISABLE\n\rCLOCK PRESCALER = UART_PRESCALER_DIV1\n\rADVANCED FEATURE: UART_ADVFEATURE_NO_INIT\n\r";
uint8_t aDmaConfigMessage[] = "\n\n\rINSTANCE = GPDMA1_CHANNEL7\n\rREQUEST = GPDMA1_REQUEST_USART3_TX\n\rBLKHWREQUEST = DMA_BREQ_SINGLE_BURST\n\rDIRECTION = DMA_MEMORY_TO_PERIPH\n\rSRCINC = DMA_SINC_INCREMENTED\n\rDESTINC = DMA_DINC_FIXED\n\rSRCDATAWIDTH = DMA_SRC_DATAWIDTH_BYTE\n\rDESTDATAWIDTH = DMA_DEST_DATAWIDTH_BYTE\n\rPRIORITY = DMA_LOW_PRIORITY_LOW_WEIGHT\n\rSRCBURSTLENGTH = 1\n\rDESTBURSTLENGTH = 1\n\rTRANSFERALLOCATEDPORT = DMA_SRC_ALLOCATED_PORT0|DMA_DEST_ALLOCATED_PORT0\n\rTRANSFEREVENTMODE = DMA_TCEM_BLOCK_TRANSFER\n\rMODE = DMA_NORMAL\n\r";
//--------------------------------------0------------------------1--------------
uint8_t *aLedOnMessage[] = {"\n\n\rLEDs are on!\n\r", "\n\n\rLEDs are off!\n\r"};
//-----------------------------------0---------1-----------2-----------3------------4-----------5---------------6-----------------7-------------------8----------------------9-------------------10-------------11----------------12--------------------13-----------
const char *commandWord[14] = {"EXIT\r\n", "exit\r\n", "help\r\n", "HELP\r\n", "RESET\r\n", "reset\r\n", " BOARD-INFO\r\n", "board-info\r\n", "UART-CONFIGINFO\r\n", "uart-configinfo\r\n", "HISTORY\r\n", "history\r\n", "DMA-CONFIGINFO\r\n", "dma-configinfo\r\n"};
//------------------------------------0-------------1-------------2---------------3--------------4-------------------5----------------6-----------------7---------
const char *auxilliaryWord[6 ] = {"LEDS-ON\r\n", "leds-on\r\n", "LEDS-OFF\r\n", "leds-off\r\n", "LEDS-STATUS\r\n", "leds-status\r\n"};
uint8_t aBoardInfoMessage[]  = "\n\n\rBoard Name: NUCLEO-H563ZI\n\rBoard ID: MB1404A\n\r";

//MAY BE USED
int i,j,k;
int indicator;
//------------

int sizer = 0;
int chamber = 0;

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void  );
static void MX_GPIO_Init(void);
static void MX_GPDMA1_Init(void);
static void MX_USART3_UART_Init(void);

int main(void)
{

	//-------------------------------------------INITS-----------------------------------
	HAL_Init();
	SystemClock_Config();
	MX_GPIO_Init();
	MX_GPDMA1_Init();
	MX_USART3_UART_Init();
	BSP_LED_Init(LED_GREEN);
	BSP_LED_Init(LED_YELLOW);
	BSP_LED_Init(LED_RED);
	//-------------------------------------END-OF-INITS-----------------------------------

	initializer(); //INITIATES THE PROCESS
	commandResponder(); //LOOP


}
void initializer (void){

	HAL_UART_Transmit_DMA(&huart3, (uint8_t*) aTxStartMessage, strlen(aTxStartMessage));
	HAL_Delay(50);
	HAL_UART_Transmit_DMA(&huart3, myBuffer2, strlen(myBuffer2));

	HAL_UART_Receive_IT(&huart3, (uint8_t*) aRxBuffer, sizeof(aRxBuffer));
}

void commandResponder(void){

	while (1)
	{
		//RX BUFFER IS FILLED VIA PC KEYBOARD, AND WHEN ENTER IS INPUTTED:
		if(aRxBuffer[strlen(&aRxBuffer[chamber])-2+chamber] == 13){


			//---------------------------------------------EXIT-AND-END-OF-PROGRAM------------------------------------------------------
			if(!strcmp((const char*) &aRxBuffer[chamber], commandWord[0]) || !strcmp((const char*) &aRxBuffer[chamber], commandWord[1])){

				HAL_UART_Transmit_DMA(&huart3, (uint8_t*) aTxEndMessage, strlen(aTxEndMessage));

				BSP_LED_On(LED1);
				BSP_LED_On(LED2);
				BSP_LED_On(LED3);

				memset(aRxBuffer, 0, sizeof(aRxBuffer));
				break;
			}

			//------------------------------------------------------------HELP REQUEST------------------------------------------------------
			else if(!strcmp((const char*) &aRxBuffer[chamber], commandWord[2]) || !strcmp((const char*) &aRxBuffer[chamber], commandWord[3])){

				sizer = strlen(&aRxBuffer[chamber]);
				chamber = chamber + sizer;

				HAL_UART_Transmit_DMA(&huart3, (uint8_t*) aHelpMessage, strlen(aHelpMessage));

			}

			//----------------------------------------------------------RESET-AND-RESTART---------------------------------------------------
			else if(!strcmp((const char*) &aRxBuffer[chamber], commandWord[4]) || !strcmp((const char*) &aRxBuffer[chamber], commandWord[5])){

				sizer = strlen(&aRxBuffer[chamber]);
				chamber += sizer;

				HAL_UART_Transmit_DMA(&huart3, (uint8_t*) aResestMessage, strlen(aResestMessage));

				HAL_Delay(50);
				HAL_NVIC_SystemReset();

			}

			//------------------------------------------------------------BOARD INFO-------------------------------------------------------
			else if(!strcmp((const char*) &aRxBuffer[chamber], commandWord[6]) || !strcmp((const char*) &aRxBuffer[chamber], commandWord[7])){

				sizer = strlen(&aRxBuffer[chamber]);
				chamber += sizer;

				HAL_UART_Transmit_DMA(&huart3, (uint8_t*) aBoardInfoMessage, strlen(aBoardInfoMessage));

			}

			//----------------------------------------------------------UART CONFIG INFO----------------------------------------------------
			else if(!strcmp((const char*) &aRxBuffer[chamber], commandWord[8]) || !strcmp((const char*) &aRxBuffer[chamber], commandWord[9])){

				sizer = strlen(&aRxBuffer[chamber]);
				chamber += sizer;

				HAL_UART_Transmit_DMA(&huart3, (uint8_t*) aUartConfigInfoMessage , strlen(aUartConfigInfoMessage));

			}

			//------------------------------------------------------------DMA CONFIG INFO---------------------------------------------------
			else if(!strcmp((const char*) &aRxBuffer[chamber], commandWord[12]) || !strcmp((const char*) &aRxBuffer[chamber], commandWord[13])){

				sizer = strlen(&aRxBuffer[chamber]);
				chamber += sizer;

				HAL_UART_Transmit_DMA(&huart3, (uint8_t*) aDmaConfigMessage , strlen(aDmaConfigMessage));

			}

			//-----------------------------------------------------------HISTORY OF COMMAND--------------------------------------------------
			else if(!strcmp((const char*) &aRxBuffer[chamber], commandWord[10]) || !strcmp((const char*) &aRxBuffer[chamber], commandWord[11])){

				sizer = strlen(&aRxBuffer[chamber]);
				chamber += sizer;

				HAL_UART_Transmit_DMA(&huart3, "\r\n\nHistory of all commands: \r\n\n\n", strlen("\r\nHistory of all commands: \r\n\n\n"));
				HAL_Delay(25);
				HAL_UART_Transmit_DMA(&huart3, aHistoryBuffer, strlen(aHistoryBuffer));

			}

			//--------------------------------------------------------------LED-MANIPULATION----------------------------------------------------------------

			//---------------------------------------------------------------LED-ON-COMMAND-------------------------------------------------------
			else if(!strcmp((const char*) &aRxBuffer[chamber], auxilliaryWord[0]) || !strcmp((const char*) &aRxBuffer[chamber], auxilliaryWord[1])){

				sizer = strlen(&aRxBuffer[chamber]);
				chamber += sizer;

				BSP_LED_On(LED1);
				BSP_LED_On(LED2);
				BSP_LED_On(LED3);

				HAL_UART_Transmit_DMA(&huart3, (uint8_t*) aLedOnMessage[0], strlen(aLedOnMessage[0]));

			}

			//---------------------------------------------------------------LED-OFF-COMMAND------------------------------------------------------
			else if(!strcmp((const char*) &aRxBuffer[chamber], auxilliaryWord[2]) || !strcmp((const char*) &aRxBuffer[chamber], auxilliaryWord[3])){

				sizer = strlen(&aRxBuffer[chamber]);
				chamber += sizer;

				BSP_LED_Off(LED1);
				BSP_LED_Off(LED2);
				BSP_LED_Off(LED3);

				HAL_UART_Transmit_DMA(&huart3, (uint8_t*) aLedOnMessage[1], strlen(aLedOnMessage[1]));

			}

			//----------------------------------------------------------------LED-STATUS COMMAND--------------------------------------------------
			else if(!strcmp((const char*) &aRxBuffer[chamber], auxilliaryWord[4]) || !strcmp((const char*) &aRxBuffer[chamber], auxilliaryWord[5])){

				sizer = strlen(&aRxBuffer[chamber]);
				chamber += sizer;

				//LEDS ARE ON
				if(BSP_LED_GetState(LED1)){

					HAL_UART_Transmit_DMA(&huart3, (uint8_t*) aLedOnMessage[0], strlen(aLedOnMessage[0]));
				}

				//LEDS ARE OFF
				else{

					//sprintf(myBuffer, "\n\nLED Status: %s", &aRxBuffer[chamber-sizer]);
					HAL_UART_Transmit_DMA(&huart3, (uint8_t*) aLedOnMessage[1], strlen(aLedOnMessage[1]));
				}

			}
			//---------------------------------------------------------CONTINUOUS-ECHO-BY-NON-LISTED-COMMANDS-------------------------------------
			else{
				sizer = strlen(&aRxBuffer[chamber]);
				chamber += sizer;

				//
				sprintf(myBuffer, "\n\nYour command: %s", &aRxBuffer[chamber-sizer]);

				if(HAL_UART_Transmit_DMA(&huart3, myBuffer, strlen(myBuffer)) == HAL_OK){
					indicator++;
				}

			}

			//WHILE ONLY
			HAL_Delay(50);
			HAL_UART_Transmit_DMA(&huart3, myBuffer2, strlen(myBuffer2));

			sprintf(&aHistoryBuffer[chamber-sizer], "%s", &aRxBuffer[chamber-sizer]);
			memset(aRxBuffer, 0, sizeof(aRxBuffer));

		}//END-OF-ENTER-VIA-KEYBOARD

	}//END-OF-WHILE(1)

}//END-OF-MAIN-FUNCTION

//------------------------CALLBACKS---------------------------------------

void HAL_UART_TxCpltCallback(UART_HandleTypeDef *huart){
}
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart){
}
void HAL_UARTEx_RxEventCallback(UART_HandleTypeDef *huart, uint16_t Size){
}

//------------------------END-OF-CALLBACKS--------------------------------

void SystemClock_Config(void)
{
	RCC_OscInitTypeDef RCC_OscInitStruct = {0};
	RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

	/** Configure the main internal regulator output voltage
	 */
	__HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE0);

	while(!__HAL_PWR_GET_FLAG(PWR_FLAG_VOSRDY)) {}

	/** Initializes the RCC Oscillators according to the specified parameters
	 * in the RCC_OscInitTypeDef structure.
	 */
	RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
	RCC_OscInitStruct.HSEState = RCC_HSE_BYPASS;
	RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
	RCC_OscInitStruct.PLL.PLLSource = RCC_PLL1_SOURCE_HSE;
	RCC_OscInitStruct.PLL.PLLM = 4;
	RCC_OscInitStruct.PLL.PLLN = 250;
	RCC_OscInitStruct.PLL.PLLP = 2;
	RCC_OscInitStruct.PLL.PLLQ = 2;
	RCC_OscInitStruct.PLL.PLLR = 2;
	RCC_OscInitStruct.PLL.PLLRGE = RCC_PLL1_VCIRANGE_1;
	RCC_OscInitStruct.PLL.PLLVCOSEL = RCC_PLL1_VCORANGE_WIDE;
	RCC_OscInitStruct.PLL.PLLFRACN = 0;
	if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
	{
		Error_Handler();
	}

	/** Initializes the CPU, AHB and APB buses clocks
	 */
	RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
			|RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2
			|RCC_CLOCKTYPE_PCLK3;
	RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
	RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
	RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
	RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;
	RCC_ClkInitStruct.APB3CLKDivider = RCC_HCLK_DIV1;

	if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_5) != HAL_OK)
	{
		Error_Handler();
	}
}

static void MX_GPDMA1_Init(void)
{

	/* USER CODE BEGIN GPDMA1_Init 0 */

	/* USER CODE END GPDMA1_Init 0 */

	/* Peripheral clock enable */
	__HAL_RCC_GPDMA1_CLK_ENABLE();

	/* GPDMA1 interrupt Init */
	HAL_NVIC_SetPriority(GPDMA1_Channel7_IRQn, 0, 0);
	HAL_NVIC_EnableIRQ(GPDMA1_Channel7_IRQn);

	/* USER CODE BEGIN GPDMA1_Init 1 */

	/* USER CODE END GPDMA1_Init 1 */
	/* USER CODE BEGIN GPDMA1_Init 2 */

	/* USER CODE END GPDMA1_Init 2 */

}

static void MX_USART3_UART_Init(void)
{

	/* USER CODE BEGIN USART3_Init 0 */

	/* USER CODE END USART3_Init 0 */

	/* USER CODE BEGIN USART3_Init 1 */

	/* USER CODE END USART3_Init 1 */
	huart3.Instance = USART3;
	huart3.Init.BaudRate = 115200;
	huart3.Init.WordLength = UART_WORDLENGTH_8B;
	huart3.Init.StopBits = UART_STOPBITS_1;
	huart3.Init.Parity = UART_PARITY_NONE;
	huart3.Init.Mode = UART_MODE_TX_RX;
	huart3.Init.HwFlowCtl = UART_HWCONTROL_NONE;
	huart3.Init.OverSampling = UART_OVERSAMPLING_16;
	huart3.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
	huart3.Init.ClockPrescaler = UART_PRESCALER_DIV1;
	huart3.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
	if (HAL_UART_Init(&huart3) != HAL_OK)
	{
		Error_Handler();
	}
	if (HAL_UARTEx_SetTxFifoThreshold(&huart3, UART_TXFIFO_THRESHOLD_1_8) != HAL_OK)
	{
		Error_Handler();
	}
	if (HAL_UARTEx_SetRxFifoThreshold(&huart3, UART_RXFIFO_THRESHOLD_1_8) != HAL_OK)
	{
		Error_Handler();
	}
	if (HAL_UARTEx_DisableFifoMode(&huart3) != HAL_OK)
	{
		Error_Handler();
	}
	/* USER CODE BEGIN USART3_Init 2 */

	/* USER CODE END USART3_Init 2 */

}

static void MX_GPIO_Init(void)
{
	/* USER CODE BEGIN MX_GPIO_Init_1 */
	/* USER CODE END MX_GPIO_Init_1 */

	/* GPIO Ports Clock Enable */
	__HAL_RCC_GPIOC_CLK_ENABLE();
	__HAL_RCC_GPIOH_CLK_ENABLE();
	__HAL_RCC_GPIOD_CLK_ENABLE();
	__HAL_RCC_GPIOA_CLK_ENABLE();

	/* USER CODE BEGIN MX_GPIO_Init_2 */
	/* USER CODE END MX_GPIO_Init_2 */
}

void Error_Handler(void)
{
	/* USER CODE BEGIN Error_Handler_Debug */
	/* User can add his own implementation to report the HAL error return state */
	__disable_irq();
	while (1)
	{
	}
	/* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
void assert_failed(uint8_t *file, uint32_t line){}
#endif
